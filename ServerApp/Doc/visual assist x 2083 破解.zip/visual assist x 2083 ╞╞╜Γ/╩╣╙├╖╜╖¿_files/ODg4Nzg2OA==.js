var _Cnf = {
	url: '',
	isValid: true
};
